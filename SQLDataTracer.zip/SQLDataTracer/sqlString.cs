﻿using System;

public class sqlString
{
	public sqlString()
	{
	}
    public static string getRecSql()
    {
        string s;
        s = "select ROWS,b.name into #tmpTableRowsCount "+
           " from sysindexes a,sysobjects b where a.indid < 2  "+
           " and a.id=b.id and b.xtype = 'U' order by rows desc ";
        return s;
             
    }
}
