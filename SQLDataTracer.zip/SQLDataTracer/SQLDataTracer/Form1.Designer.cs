﻿namespace SQLDataTracer
{
    partial class fmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmMain));
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbAlltable = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbTables = new System.Windows.Forms.ListBox();
            this.dgvData = new System.Windows.Forms.DataGridView();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.cbServerName = new System.Windows.Forms.ComboBox();
            this.cbSecurity = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtpassword = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbDBname = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbLanguage = new System.Windows.Forms.ComboBox();
            this.tcmain = new System.Windows.Forms.TabControl();
            this.tpREC = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgRecTracing = new System.Windows.Forms.DataGridView();
            this.TableName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrigRecords = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.curRecords = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VaranceRecords = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.lbTime = new System.Windows.Forms.Label();
            this.picbox = new System.Windows.Forms.PictureBox();
            this.btEnd = new System.Windows.Forms.Button();
            this.btBegin = new System.Windows.Forms.Button();
            this.tpData = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.txtTableName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lbData = new System.Windows.Forms.Label();
            this.pbData = new System.Windows.Forms.PictureBox();
            this.dataBegin = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.img = new System.Windows.Forms.ImageList(this.components);
            this.tmMain = new System.Windows.Forms.Timer(this.components);
            this.tmData = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.tcmain.SuspendLayout();
            this.tpREC.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRecTracing)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox)).BeginInit();
            this.tpData.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbData)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer2
            // 
            resources.ApplyResources(this.splitContainer2, "splitContainer2");
            this.splitContainer2.BackColor = System.Drawing.SystemColors.Highlight;
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            resources.ApplyResources(this.splitContainer2.Panel1, "splitContainer2.Panel1");
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer2.Panel2
            // 
            resources.ApplyResources(this.splitContainer2.Panel2, "splitContainer2.Panel2");
            this.splitContainer2.Panel2.Controls.Add(this.dgvData);
            // 
            // splitContainer1
            // 
            resources.ApplyResources(this.splitContainer1, "splitContainer1");
            this.splitContainer1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            resources.ApplyResources(this.splitContainer1.Panel1, "splitContainer1.Panel1");
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            resources.ApplyResources(this.splitContainer1.Panel2, "splitContainer1.Panel2");
            this.splitContainer1.Panel2.Controls.Add(this.groupBox2);
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.lbAlltable);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // lbAlltable
            // 
            resources.ApplyResources(this.lbAlltable, "lbAlltable");
            this.lbAlltable.FormattingEnabled = true;
            this.lbAlltable.Name = "lbAlltable";
            this.lbAlltable.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            this.lbAlltable.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lbAlltable_MouseDoubleClick);
            // 
            // groupBox2
            // 
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Controls.Add(this.lbTables);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // lbTables
            // 
            resources.ApplyResources(this.lbTables, "lbTables");
            this.lbTables.FormattingEnabled = true;
            this.lbTables.Name = "lbTables";
            this.lbTables.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lbTables_MouseClick);
            this.lbTables.SelectedIndexChanged += new System.EventHandler(this.lbTables_SelectedIndexChanged);
            this.lbTables.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lbTables_MouseDoubleClick);
            // 
            // dgvData
            // 
            resources.ApplyResources(this.dgvData, "dgvData");
            this.dgvData.AllowUserToAddRows = false;
            this.dgvData.AllowUserToOrderColumns = true;
            this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvData.Name = "dgvData";
            // 
            // flowLayoutPanel1
            // 
            resources.ApplyResources(this.flowLayoutPanel1, "flowLayoutPanel1");
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.cbServerName);
            this.flowLayoutPanel1.Controls.Add(this.cbSecurity);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.txtusername);
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.txtpassword);
            this.flowLayoutPanel1.Controls.Add(this.label4);
            this.flowLayoutPanel1.Controls.Add(this.cbDBname);
            this.flowLayoutPanel1.Controls.Add(this.label7);
            this.flowLayoutPanel1.Controls.Add(this.textBox1);
            this.flowLayoutPanel1.Controls.Add(this.label6);
            this.flowLayoutPanel1.Controls.Add(this.cbLanguage);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // cbServerName
            // 
            resources.ApplyResources(this.cbServerName, "cbServerName");
            this.cbServerName.FormattingEnabled = true;
            this.cbServerName.Name = "cbServerName";
            // 
            // cbSecurity
            // 
            resources.ApplyResources(this.cbSecurity, "cbSecurity");
            this.cbSecurity.Checked = true;
            this.cbSecurity.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbSecurity.Name = "cbSecurity";
            this.cbSecurity.UseVisualStyleBackColor = true;
            this.cbSecurity.CheckedChanged += new System.EventHandler(this.cbSecurity_CheckedChanged);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // txtusername
            // 
            resources.ApplyResources(this.txtusername, "txtusername");
            this.txtusername.Name = "txtusername";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // txtpassword
            // 
            resources.ApplyResources(this.txtpassword, "txtpassword");
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.PasswordChar = '*';
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // cbDBname
            // 
            resources.ApplyResources(this.cbDBname, "cbDBname");
            this.cbDBname.FormattingEnabled = true;
            this.cbDBname.Name = "cbDBname";
            this.cbDBname.Enter += new System.EventHandler(this.cbDBname_Enter);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // cbLanguage
            // 
            resources.ApplyResources(this.cbLanguage, "cbLanguage");
            this.cbLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLanguage.FormattingEnabled = true;
            this.cbLanguage.Items.AddRange(new object[] {
            resources.GetString("cbLanguage.Items"),
            resources.GetString("cbLanguage.Items1")});
            this.cbLanguage.Name = "cbLanguage";
            this.cbLanguage.SelectedIndexChanged += new System.EventHandler(this.cbLanguage_SelectedIndexChanged);
            // 
            // tcmain
            // 
            resources.ApplyResources(this.tcmain, "tcmain");
            this.tcmain.Controls.Add(this.tpREC);
            this.tcmain.Controls.Add(this.tpData);
            this.tcmain.Controls.Add(this.tabPage1);
            this.tcmain.Name = "tcmain";
            this.tcmain.SelectedIndex = 0;
            this.tcmain.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tpREC
            // 
            resources.ApplyResources(this.tpREC, "tpREC");
            this.tpREC.Controls.Add(this.panel2);
            this.tpREC.Controls.Add(this.panel1);
            this.tpREC.Name = "tpREC";
            this.tpREC.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Controls.Add(this.dgRecTracing);
            this.panel2.Name = "panel2";
            // 
            // dgRecTracing
            // 
            resources.ApplyResources(this.dgRecTracing, "dgRecTracing");
            this.dgRecTracing.AllowUserToAddRows = false;
            this.dgRecTracing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRecTracing.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TableName,
            this.OrigRecords,
            this.curRecords,
            this.VaranceRecords});
            this.dgRecTracing.MultiSelect = false;
            this.dgRecTracing.Name = "dgRecTracing";
            this.dgRecTracing.ReadOnly = true;
            // 
            // TableName
            // 
            resources.ApplyResources(this.TableName, "TableName");
            this.TableName.Name = "TableName";
            this.TableName.ReadOnly = true;
            // 
            // OrigRecords
            // 
            resources.ApplyResources(this.OrigRecords, "OrigRecords");
            this.OrigRecords.Name = "OrigRecords";
            this.OrigRecords.ReadOnly = true;
            // 
            // curRecords
            // 
            resources.ApplyResources(this.curRecords, "curRecords");
            this.curRecords.Name = "curRecords";
            this.curRecords.ReadOnly = true;
            // 
            // VaranceRecords
            // 
            resources.ApplyResources(this.VaranceRecords, "VaranceRecords");
            this.VaranceRecords.Name = "VaranceRecords";
            this.VaranceRecords.ReadOnly = true;
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.lbTime);
            this.panel1.Controls.Add(this.picbox);
            this.panel1.Controls.Add(this.btEnd);
            this.panel1.Controls.Add(this.btBegin);
            this.panel1.Name = "panel1";
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbTime
            // 
            resources.ApplyResources(this.lbTime, "lbTime");
            this.lbTime.Name = "lbTime";
            // 
            // picbox
            // 
            resources.ApplyResources(this.picbox, "picbox");
            this.picbox.Image = global::SQLDataTracer.Properties.Resources._5;
            this.picbox.InitialImage = global::SQLDataTracer.Properties.Resources._3;
            this.picbox.Name = "picbox";
            this.picbox.TabStop = false;
            // 
            // btEnd
            // 
            resources.ApplyResources(this.btEnd, "btEnd");
            this.btEnd.Name = "btEnd";
            this.btEnd.UseVisualStyleBackColor = true;
            this.btEnd.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btBegin
            // 
            resources.ApplyResources(this.btBegin, "btBegin");
            this.btBegin.Name = "btBegin";
            this.btBegin.UseVisualStyleBackColor = true;
            this.btBegin.Click += new System.EventHandler(this.btBegin_Click);
            // 
            // tpData
            // 
            resources.ApplyResources(this.tpData, "tpData");
            this.tpData.Controls.Add(this.splitContainer2);
            this.tpData.Controls.Add(this.panel3);
            this.tpData.Name = "tpData";
            this.tpData.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.txtTableName);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.lbData);
            this.panel3.Controls.Add(this.pbData);
            this.panel3.Controls.Add(this.dataBegin);
            this.panel3.Name = "panel3";
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // txtTableName
            // 
            resources.ApplyResources(this.txtTableName, "txtTableName");
            this.txtTableName.Name = "txtTableName";
            this.txtTableName.TextChanged += new System.EventHandler(this.txtTableName_TextChanged);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // lbData
            // 
            resources.ApplyResources(this.lbData, "lbData");
            this.lbData.Name = "lbData";
            // 
            // pbData
            // 
            resources.ApplyResources(this.pbData, "pbData");
            this.pbData.Image = global::SQLDataTracer.Properties.Resources._5;
            this.pbData.InitialImage = global::SQLDataTracer.Properties.Resources._3;
            this.pbData.Name = "pbData";
            this.pbData.TabStop = false;
            // 
            // dataBegin
            // 
            resources.ApplyResources(this.dataBegin, "dataBegin");
            this.dataBegin.Name = "dataBegin";
            this.dataBegin.UseVisualStyleBackColor = true;
            this.dataBegin.Click += new System.EventHandler(this.dataBegin_Click);
            // 
            // tabPage1
            // 
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Controls.Add(this.richTextBox1);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            resources.ApplyResources(this.richTextBox1, "richTextBox1");
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            // 
            // img
            // 
            this.img.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("img.ImageStream")));
            this.img.TransparentColor = System.Drawing.Color.Transparent;
            this.img.Images.SetKeyName(0, "1.png");
            this.img.Images.SetKeyName(1, "2.png");
            this.img.Images.SetKeyName(2, "3.png");
            this.img.Images.SetKeyName(3, "4.png");
            this.img.Images.SetKeyName(4, "5.png");
            this.img.Images.SetKeyName(5, "6.png");
            // 
            // tmMain
            // 
            this.tmMain.Interval = 1000;
            this.tmMain.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tmData
            // 
            this.tmData.Interval = 1000;
            this.tmData.Tick += new System.EventHandler(this.tmData_Tick);
            // 
            // fmMain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tcmain);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "fmMain";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.tcmain.ResumeLayout(false);
            this.tpREC.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgRecTracing)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox)).EndInit();
            this.tpData.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbData)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TabControl tcmain;
        private System.Windows.Forms.TabPage tpREC;
        private System.Windows.Forms.TabPage tpData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbServerName;
        private System.Windows.Forms.CheckBox cbSecurity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbDBname;
        private System.Windows.Forms.MaskedTextBox txtpassword;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgRecTracing;
        private System.Windows.Forms.Button btBegin;
        private System.Windows.Forms.Button btEnd;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ImageList img;
        private System.Windows.Forms.PictureBox picbox;
        private System.Windows.Forms.Timer tmMain;
        private System.Windows.Forms.Label lbTime;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox lbTables;
        private System.Windows.Forms.DataGridView dgvData;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button dataBegin;
        private System.Windows.Forms.PictureBox pbData;
        private System.Windows.Forms.Timer tmData;
        private System.Windows.Forms.Label lbData;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox lbAlltable;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtTableName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbLanguage;
        private System.Windows.Forms.DataGridViewTextBoxColumn TableName;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrigRecords;
        private System.Windows.Forms.DataGridViewTextBoxColumn curRecords;
        private System.Windows.Forms.DataGridViewTextBoxColumn VaranceRecords;



    }
}

