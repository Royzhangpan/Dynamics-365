﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;




namespace SQLDataTracer
{
    public partial class fmMain : Form
    {
        SqlConnection conn ;
        bool dbOpened,DBAdded,usrChangeLg=false;
        Bitmap[] map = { Properties.Resources._1, Properties.Resources._2, Properties.Resources._3,
                       Properties.Resources._4,Properties.Resources._5,Properties.Resources._6};
        int i = 1,t,tData,j=1;
        
        double ver = 0.9;
        
        public fmMain()
        {
            System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("zh-CN");
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {           
   /*
            foreach (string str in GetSqlServerName())
            {
                cbServerName.Items.Add(str);
            }
    * */
            DBAdded = false;

            this.Text = this.Text + "  ,V " + (ver).ToString();
            //cbLanguage.SelectedIndex = 0;
            //this.changeLanguage();
            
        }
        private void changeLanguage()
        {
            if (usrChangeLg == false) return;
            if (cbLanguage.SelectedIndex == 0)
            {
                //this.Controls.Clear(); 
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("zh-Hans");
                //InitializeComponent();
                
                //cbLanguage.SelectedIndex = 0;
            }
            else if (cbLanguage.SelectedIndex == 1)
            {
                //this.Controls.Clear();
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-US");
                //InitializeComponent();
                //cbLanguage.SelectedIndex = 1;
            }
            usrChangeLg = false;
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            
        }
        
        private void cbSecurity_CheckedChanged(object sender, EventArgs e)
        {
            if (this.cbSecurity.Checked == false)
            {
                this.txtpassword.Enabled = true;
                this.txtusername.Enabled = true;
            }
            else
            {
                this.txtpassword.Enabled = false;
                this.txtusername.Enabled = false;
            }
        }
        
        public static string[] GetSqlServerName()
        {
            SqlDataSourceEnumerator sqlserver = SqlDataSourceEnumerator.Instance;
            DataTable db = sqlserver.GetDataSources();
            string[] Name = new string[db.Rows.Count];
            for (int i = 0; i < db.Rows.Count; i++)
            {
                Name[i] = db.Rows[i]["Servername"].ToString(); 
                /*string.Format("IsClustered: {0:10}", db.Rows[i]["isclustered"])
                 + " " +
                  string.Format("\nServerName: {0:15}", db.Rows[i]["Servername"])
                 + " " +
                  string.Format("\nInstanceName: {0:20}", db.Rows[i]["instancename"])
                 + " " +
                 string.Format("\nVersion: {0:20}\n", db.Rows[i]["version"]);
                 * */ 
            }
            return Name;
        }
        
        public void DBcon()
        {
            string ConnStr;
            //conn.ConnectionTimeout = 2000000;
            if(cbSecurity.Checked)
            {
                ConnStr = "server="+cbServerName.Text+";database="+cbDBname.Text+
                            "; integrated security=sspi;Connection Timeout=90";                
            }
            else
            {            
                ConnStr = "server="+cbServerName.Text+";database="+cbDBname.Text+
                    "; User ID=" + txtusername.Text + ";Password=" + txtpassword.Text + ";"; 
            } 
            conn  = new SqlConnection(ConnStr);
            try
            {
                conn.Open();
                dbOpened = true;
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
                dbOpened = false;
            }
        }
        
        private void btBegin_Click(object sender, EventArgs e)
        {
            if (cbDBname.Text == "")
            {
                MessageBox.Show("Data Base name can not be empty.");
                return;
            }
            dgRecTracing.Rows.Clear();
            if(dbOpened  == true)  conn.Close();
            this.DBcon();
            SqlCommand thiscommand = conn.CreateCommand();
            thiscommand.CommandText = getRecSql_Begin();
            thiscommand.ExecuteNonQuery();
            tmMain.Enabled = true;
            t = 0;
        }  

        private void button1_Click_1(object sender, EventArgs e)
        {
            string TableName;
            SqlCommand thiscommand = conn.CreateCommand();
            thiscommand.CommandText = getRecSql_End();
            SqlDataReader rstList  = thiscommand.ExecuteReader();
            while (rstList.Read())
            {
                TableName = (string)rstList["name"];
                if(TableName != "")
                    dgRecTracing.Rows.Add
                        (
                            new object[] 
                            {
                                TableName ,
                                (string)rstList["RowS"].ToString(),
                                (string)rstList["RowS2"].ToString(),
                                (string)rstList["VarQty"].ToString()
                            }
                        );                
            }
            rstList.Close();
            tmMain.Enabled = false;
            picbox.Image = map[4];
        }

        public static string getRecSql_Begin()
        {
            string s;
            s = "select b.name,a.id,ROWS,9999999999 as rows2 into #tmpTableRowsCount" +
               " from sysindexes a,sysobjects b where a.indid < 2  " +
               " and a.id=b.id and b.xtype = 'U' and b.category=0  order by rows desc ";
            return s;
        }

        public static string getRecSql_End()
        {
            string s;
            s = " update #tmpTableRowsCount set  rows2 = b.ROWS " +
                " from sysindexes b where b.id = #tmpTableRowsCount.id " +
                " select name,RowS,rows2,(rows2-rows) as VarQty from #tmpTableRowsCount where (rows2-RowS) <>0 ";
            return s;
        }

        private void cbDBname_Enter(object sender, EventArgs e)
        {
            if (DBAdded == false)
            {
                if (dbOpened == true)
                    conn.Close();
                this.DBcon();

                SqlCommand thiscommand = conn.CreateCommand();
                thiscommand.CommandText = "Select name From Master..SysDatabases order By Name";
                SqlDataReader thisSqlDataReader = thiscommand.ExecuteReader();
                while (thisSqlDataReader.Read())
                {
                    cbDBname.Items.Add(thisSqlDataReader["name"].ToString());
                }
                DBAdded = true;
                //thisSqlDataReader.Close();               
            }
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (i == 4) i = 1;
            picbox.Image = map[i];
            i++;
            t = t + 10000;
            this.lbTime.Text = GetAllTime(t);
        }
       
        public string GetAllTime(int time)
        {
            string hh, mm, ss, fff;

            int f = time % 100; // 毫秒   
            int s = time / 100; // 转化为秒
            int m = s / 60;     // 分
            int h = m / 60;     // 时
            s = s % 60;     // 秒 

            //毫秒格式00
            if (f < 10)
            {
                fff = "0" + f.ToString();
            }
            else
            {
                fff = f.ToString();
            }

            //秒格式00
            if (s < 10)
            {
                ss = "0" + s.ToString();
            }
            else
            {
                ss = s.ToString();
            }

            //分格式00
            if (m < 10)
            {
                mm = "0" + m.ToString();
            }
            else
            {
                mm = m.ToString();
            }

            //时格式00
            if (h < 10)
            {
                hh = "0" + h.ToString();
            }
            else
            {
                hh = h.ToString();
            }

            //返回 hh:mm:ss.ff            
            return hh + ":" + mm + ":" + ss + "." + fff;
        }
        
        private void lbTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void dataBegin_Click(object sender, EventArgs e)
        {
            string sqlStr;
            if (cbDBname.Text == "")
            {
                MessageBox.Show("Data Base name can not be empty.");
                return;
            }            
            if (dbOpened == true) conn.Close();
            this.DBcon();
            SqlCommand thiscommand = conn.CreateCommand();
            thiscommand.CommandTimeout = 900;
            thiscommand.CommandText = getDataSql_begin();
            thiscommand.ExecuteNonQuery();
            for (int i = lbTables.Items.Count - 1; i >= 0; i--)
            {
                sqlStr = " Exec sys.sp_cdc_enable_table 'dbo', " + lbTables.Items[i].ToString() + ", @role_name = NULL";
                thiscommand.CommandText = sqlStr;
                thiscommand.ExecuteNonQuery();
            }           

            tmData.Enabled = true;
            tData = 1; 
        }
        
        private string getDataSql_begin()
        {
            string s;
            s = " DECLARE  @name nvarchar(100) " +
                " SET nocount  ON  " +
                " EXEC sp_changedbowner 'sa' " +
                " Exec sys.sp_cdc_enable_db ";           
            return s;        
        }

        private void tmData_Tick(object sender, EventArgs e)
        {
            if (j == 4) j = 1;
            pbData.Image = map[j];
            j++;
            tData = tData + 10000;
            this.lbData.Text = GetAllTime(tData);
        }

     

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.addTables();
        }
        
        public void addTables()
        {
            string curtableName = "";
            if (tcmain.SelectedIndex == 1)
            {
                try
                {
                    if (dbOpened == true)
                        conn.Close();
                    this.DBcon();
                    lbAlltable.Items.Clear();

                    SqlCommand thiscommand = conn.CreateCommand();
                    if (txtTableName.Text != "")
                        curtableName = " and name like '%" + txtTableName.Text + "%'";
                    thiscommand.CommandText = "SELECT name FROM   sysobjects WHERE  xtype = 'U' " +
                        "and name not like 'DEL_%' and category=0 " + curtableName + " order by name";
                    SqlDataReader thisSqlDataReader = thiscommand.ExecuteReader();
                    while (thisSqlDataReader.Read())
                    {
                        lbAlltable.Items.Add(thisSqlDataReader["name"].ToString());
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message); 
                }                    
            }
        }

        private void txtTableName_TextChanged(object sender, EventArgs e)
        {
            this.addTables();
        }

        private void lbAlltable_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            lbTables.Items.Add(lbAlltable.SelectedItem.ToString());
            //lbTables.Items.Add("custTable");
        }

        private void lbTables_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //lbAlltable.Items.Remove(lbAlltable.SelectedItem);


            lbTables.Items.Remove(lbTables.SelectedItem);
           // }
        }

        private void lbTables_MouseClick(object sender, MouseEventArgs e)
        {
            string TableName,sql= "";

            try
            {

                //dgvData.Rows.Clear();
                TableName = lbTables.SelectedItem.ToString();

                if (dbOpened == true)
                    conn.Close();
                this.DBcon();
                sql = getSelSql(TableName);

                SqlDataAdapter myAdapter = new SqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                myAdapter.Fill(ds);
                dgvData.DataSource = ds.Tables[0];
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message + ",sql=" + sql);
            }
        }
        
        private string getSelSql(string _tableName)
        {
            string strsql = "", curField = "", allField = "", cdcTable = "";
            int a = 0, b = 0,i=0,j=0;
            string[] arrField = new string[1000];
            SqlDataReader thisSqlDataReaderFld;
            SqlDataReader thisSqlDataReader;
            SqlCommand thiscommand = conn.CreateCommand();
            SqlCommand thiscommandFld = conn.CreateCommand();
            cdcTable = "cdc.dbo_"+_tableName+"_CT"; 
            thiscommand.CommandText = "  select a.name from syscolumns a,sysobjects b where a.id=b.id and "+
                                       " a.name not like 'DEL_%' and a.xtype <>34 and b.name='" + _tableName + "'";
            thisSqlDataReader = thiscommand.ExecuteReader();
            while (thisSqlDataReader.Read())
            {
                
                curField = thisSqlDataReader["name"].ToString();
                arrField[i] = curField;
                i++;
            }
            thisSqlDataReader.Close();
            for(j=0;j<i;j++)
            {
                curField = arrField[j];
                thiscommandFld.CommandText = "select count("+curField+") as cntRec from "+cdcTable;
                thisSqlDataReaderFld = thiscommandFld.ExecuteReader();
                thisSqlDataReaderFld.Read();
                a = (int)thisSqlDataReaderFld["cntRec"];
                thisSqlDataReaderFld.Close();

                thiscommandFld.CommandText = "select count(" + curField + ") as cntRec from "+cdcTable+" group by " + curField;
                thisSqlDataReaderFld = thiscommandFld.ExecuteReader();
                thisSqlDataReaderFld.Read();
                b = (int)thisSqlDataReaderFld["cntRec"];
                thisSqlDataReaderFld.Close();
                if (a != b)
                {
                    /*if(allField == "")
                    {
                        allField = curField;
                    }
                    else
                    {*/
                    allField = allField + "," + curField;
                    // }
                }
                else if (a == 1)
                    allField = allField + "," + curField;
            }
            strsql = "select Operation = case __$operation when 2 then 'Ins' when 3 then 'Ori' when 4 then 'upd' end,RecID as RID" + allField + " from " + cdcTable;
            return strsql;
        }

        private void button1_Click_2(object sender, EventArgs e)
        {     
            try
            {
                if (dbOpened == true) conn.Close();
                this.DBcon();
                SqlCommand thiscommand = conn.CreateCommand();
                thiscommand.CommandTimeout = 900;
                thiscommand.CommandText = " Exec sys.sp_cdc_disable_db";
                thiscommand.ExecuteNonQuery();
                MessageBox.Show("clear finished.");
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i<=(dgRecTracing.RowCount - 1); i++)
            {
                lbTables.Items.Add(dgRecTracing.Rows[i].Cells[0].Value);
            }
        }

        private void cbLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            usrChangeLg = true;
            this.changeLanguage();
        }
    }
}
